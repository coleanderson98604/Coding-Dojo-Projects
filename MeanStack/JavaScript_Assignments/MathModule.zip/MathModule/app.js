var mathlib = require('./mathlib.js')
console.log(mathlib.add(1,2));
console.log(mathlib.multiply(9,9));
console.log(mathlib.square(6));
console.log(mathlib.random(20,60));