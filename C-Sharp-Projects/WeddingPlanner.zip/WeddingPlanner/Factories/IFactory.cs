using WeddingPlanner.Models;
using System.Collections.Generic;

//namespace WeddingPlanner.Factory{
//    public interface IFactory<T> where T : BaseEntity{

//    }
//}
